package org.cap.model;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Test {
	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		
		Routetable routetable=new Routetable();
		routetable.setRoute_path("MIPL-Tambaram");
		routetable.setNo_of_seats_occupied(15);
		routetable.setTotal_seats(45);
		routetable.setBus_no("2A");
		routetable.setDriver_name("RAMU");
		routetable.setTotal_km(45.0);
		LoginBean loginBean=new LoginBean("shiva", "shiva123");
		LoginBean loginBean1=new LoginBean("neeraj", "neeraj123");
		LoginBean loginBean2=new LoginBean("manoj", "manoj123");
		
		entityManager.persist(routetable);
		entityManager.persist(loginBean);
		entityManager.persist(loginBean1);
		entityManager.persist(loginBean2);
		
		transaction.commit();
		entityManager.close();
	}

}
