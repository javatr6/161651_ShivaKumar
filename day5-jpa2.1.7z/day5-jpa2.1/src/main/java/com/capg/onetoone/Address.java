package com.capg.onetoone;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Address {

	@Id
	private int addId;
	private String address;
	

	@OneToOne
	@JoinColumn(name="custfk")
	private Customer customer;


	public Address(int addId, String address, Customer customer) {
		super();
		this.addId = addId;
		this.address = address;
		this.customer = customer;
	}


	public int getAddId() {
		return addId;
	}


	public void setAddId(int addId) {
		this.addId = addId;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public Customer getCustomer() {
		return customer;
	}


	public void setCustomer(Customer customer) {
		this.customer = customer;
	}


	@Override
	public String toString() {
		return "Address [addId=" + addId + ", address=" + address + ", customer=" + customer + "]";
	}
	
	
}
