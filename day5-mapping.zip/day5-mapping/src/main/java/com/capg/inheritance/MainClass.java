package com.capg.inheritance;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String args[]) {
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction(); 
		
		transaction.begin();
		
		Project project=new Project(101,"State Bank");
		
		Module module=new Module();
		module.setProjectId(121);
		module.setProjectName("FS");
		module.setModuleName("Login Module");
		
		Task task=new Task();
		task.setProjectId(211);
		task.setProjectName("Digital");
		task.setModuleName("Validation");
		task.setTaskName("Client Side Validate");
		
		entityManager.persist(project);
		entityManager.persist(module);
		entityManager.persist(task);
		
		transaction.commit();
		entityManager.close();
	}
}
