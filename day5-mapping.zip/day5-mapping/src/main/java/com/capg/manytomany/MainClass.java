package com.capg.manytomany;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) {
	
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction(); 
		
		transaction.begin();
		
		Events corejava=new Events();
		corejava.setEventId("1001-COREJAVA");
		corejava.setEventName("COREJAVA");
		
		Events python=new Events();
		python.setEventId("1002-PYTHON");
		python.setEventName("PYTHON");
		
		Events angularjs=new Events();
		angularjs.setEventId("1003-ANGULARJS");
		angularjs.setEventName("ANGULARJS");
		
		Delegates shiva=new Delegates(112,"shiva");
		Delegates neeraj=new Delegates(15,"neeraj");
		Delegates manoj=new Delegates(115,"manoj");
		Delegates akhil=new Delegates(123,"akhil");
		Delegates vamsi=new Delegates(156,"vamsi");
		
		entityManager.persist(neeraj);
		entityManager.persist(manoj);
		entityManager.persist(akhil);
		entityManager.persist(vamsi);
		entityManager.persist(shiva);
		
		shiva.getEvents().add(corejava);
		neeraj.getEvents().add(python);
		shiva.getEvents().add(angularjs);
		akhil.getEvents().add(corejava);
		vamsi.getEvents().add(python);
		neeraj.getEvents().add(corejava);
		manoj.getEvents().add(python);
		akhil.getEvents().add(angularjs);
		

		
		
		entityManager.persist(corejava);
		entityManager.persist(angularjs);
		entityManager.persist(python);
		
		
		
		transaction.commit();
		entityManager.close();
	}

}
