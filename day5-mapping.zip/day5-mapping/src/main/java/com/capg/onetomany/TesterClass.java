package com.capg.onetomany;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class TesterClass {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction(); 
		
		transaction.begin();
		Company wipro=new Company("Wipro consultancies");
		Company capg=new Company("Capgemini");
		
		Employee employee=new Employee(101,"Shiva",wipro);
		Employee employee1=new Employee(102,"Vamsi",capg);
		Employee employee2=new Employee(103,"SreeRam",wipro);
		Employee employee3=new Employee(104,"Neeraj",capg);
		
		entityManager.persist(wipro);
		entityManager.persist(capg);
		entityManager.persist(employee);
		entityManager.persist(employee1);
		entityManager.persist(employee2);
		entityManager.persist(employee3);
		transaction.commit();
		entityManager.close();

	}

}
